from django.db import models

#Definimos los objetos que vamos a tener en la BD

class ErrorLog(models.Model):
    # es igual a poner varchar(10)
    codigo = models.CharField(max_length=10)
    # es igual a poner longText
    mensaje = models.TextField()
    # es igual a poner Date(now())
    fecha = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{codigo} - {mensaje}"